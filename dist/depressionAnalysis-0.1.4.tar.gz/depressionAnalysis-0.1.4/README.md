# depressionAnalysis
A pip package for detecting depression in social media posts. Read more about the project at https://www.heianperiodchatroom.host/post/9
