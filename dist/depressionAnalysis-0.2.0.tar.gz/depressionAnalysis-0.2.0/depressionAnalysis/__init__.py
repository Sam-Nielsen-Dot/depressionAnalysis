"""
depressionAnalysis

A package for detecting depression in tweets
"""



__version__ = "0.1.0"
__author__ = 'Sam Nielsen'
__credits__ = 'None'
