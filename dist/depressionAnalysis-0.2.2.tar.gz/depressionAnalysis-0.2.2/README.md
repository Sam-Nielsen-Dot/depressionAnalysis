# depressionAnalysis
A pip package for detecting depression in social media posts. Read more about the project at https://www.heianperiodchatroom.host/post/9

Read the attached wiki to understand the functionality of the program.
